<?php
$to = "info@asiamedia.kz";
$topic = "Заявка AsiaMedia";
$message .= "Имя: ".$_POST['name']."<br>";
$message .= "Телефон: ".$_POST['phone']."<br>";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
$send = mail($to, $topic, $message, $headers);