"use strict";

const inputs = document.querySelectorAll("input");
const loginWindow = document.querySelector(".login");
const loginForm = document.querySelector(".login__form");
const videoWindow = document.querySelector(".preview");

if (localStorage.getItem("name")) {
	loginForm.remove();
	videoWindow.classList.add("active");
}

const toPreview = () => {
	loginWindow.classList.add("inactive");
	videoWindow.classList.add("active");
	setTimeout(() => {
		loginForm.remove();
	}, 750);
};

document.addEventListener("DOMContentLoaded", () => {
	inputs.forEach((input) => {
		input.addEventListener("blur", () => {
			if (input.value.trim() !== "") {
				input.classList.add("has-value");
			} else {
				input.classList.remove("has-value");
			}
		});
	});

	loginForm.addEventListener("submit", function (el) {
		el.preventDefault();
	
		if (inputs[0].value.trim() == "") return;
		
		let request = new XMLHttpRequest();
		request.onreadystatechange = function () {
			if (
				loginForm.readyState === XMLHttpRequest.DONE &&
				loginForm.status === 200
			) {
				toPreview();
				localStorage.setItem("name", inputs[0].value.trim());
			}
		};
	
		request.open(loginForm.method, loginForm.action);
		console.log(this);
		let data = new FormData(this);
		request.send(data);
	});
});
